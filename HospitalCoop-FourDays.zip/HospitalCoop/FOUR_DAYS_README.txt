FOUR SHARED DAYS UPDATE
Launch DisabilitySimulator.exe from this folder.
Copy this ENTIRE folder to BOTH PCs, including DisabilitySimulator_Data, MonoBleedingEdge and UnityPlayer.dll.
Both host and guest must run the same updated build.
Start on Day 1. Each captured pair advances to the next day; the fourth pair capture ends the game. Puzzle progress carries across days. Replay requires both players and restarts on Day 1. Includes all guest performance and earlier gameplay changes.